﻿// File: Services/GhPluginBlocker.cs
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using GhPlugins.Models;
using Rhino;

namespace GhPlugins.Services
{
    public static class GhPluginBlocker
    {
        private const string DisabledSuffix = ".disabled";

        // Always-on core providers we should never block (case-insensitive file match)
        private static readonly string[] AlwaysOnFileHints = new[]
        {
            "ghpython",          // Rhino 7/8 GhPython
            "gh_cp",             // CPython bridge names sometimes start like this
            "gh-cpython",
            "ghpython2",         // in case of legacy names
        };

        private static readonly string[] DisabledPatterns =
        {
            "*.gha.disabled", "*.ghuser.disabled", "*.ghpy.disabled"
        };

        // ---------- Public API ----------

        public static void UnblockEverything()
        {
            foreach (var root in GetKnownRoots())
            {
                if (!Directory.Exists(root)) continue;

                foreach (var pat in DisabledPatterns)
                {
                    foreach (var disabled in SafeEnumerateFiles(root, pat))
                    {
                        var original = disabled.Substring(0, disabled.Length - DisabledSuffix.Length);
                        try
                        {
                            if (File.Exists(original))
                                File.Delete(disabled);
                            else
                                File.Move(disabled, original);

                            RhinoApp.WriteLine("[Gh Mode Manager] restored: " + original);
                        }
                        catch (Exception ex)
                        {
                            RhinoApp.WriteLine("[Gh Mode Manager] restore failed: " + disabled + " → " + ex.Message);
                        }
                    }
                }
            }
        }

        // Compare by Name (not reference), then expand families
        public static void applyPluginDisable(List<PluginItem> allPlugins, ModeConfig mf)
        {
            if (allPlugins == null || mf?.Plugins == null) return;

            var selectedNames = new HashSet<string>(
                mf.Plugins.Where(p => !string.IsNullOrWhiteSpace(p.Name))
                          .Select(p => p.Name),
                StringComparer.OrdinalIgnoreCase);

            foreach (var plugin in allPlugins)
                plugin.IsSelected = plugin != null && selectedNames.Contains(plugin.Name);

            ExpandSelectionToFamilies(allPlugins);
        }

        public static void ApplyBlocking(List<PluginItem> allPlugins)
        {
            if (allPlugins == null || allPlugins.Count == 0)
            {
                RhinoApp.WriteLine("[Gh Mode Manager] No plugins to process.");
                return;
            }

            // Make sure family expansion happened
            ExpandSelectionToFamilies(allPlugins);

            foreach (var p in allPlugins)
            {
                try
                {
                    if (p == null) continue;

                    // Prefer Program Files copy (can’t rename)
                    int sysIdx = p.GhaPaths?.FindIndex(IsSystemComponentPath) ?? -1;
                    if (sysIdx >= 0) p.ActiveVersionIndex = sysIdx;

                    RhinoApp.WriteLine($"[Gh Mode Manager] Processing: {p.Name} (Selected={p.IsSelected}, ActiveIndex={p.ActiveVersionIndex})");

                    if (!p.IsSelected)
                    {
                        BlockMany(p.GhaPaths, ".gha");
                        BlockMany(p.UserobjectPath, ".ghuser");
                        BlockMany(p.ghpyPath, ".ghpy");
                        continue;
                    }

                    // Selected → GHAs
                    if (p.GhaPaths != null && p.GhaPaths.Count > 0)
                    {
                        if (p.ActiveVersionIndex < 0 || p.ActiveVersionIndex >= p.GhaPaths.Count)
                        {
                            RhinoApp.WriteLine($"[Gh Mode Manager] ⚠️ {p.Name}: ActiveVersionIndex out of range → blocking all GHAs.");
                            BlockMany(p.GhaPaths, ".gha");
                        }
                        else
                        {
                            for (int i = 0; i < p.GhaPaths.Count; i++)
                            {
                                var path = p.GhaPaths[i];
                                if (string.IsNullOrWhiteSpace(path)) continue;

                                if (i == p.ActiveVersionIndex)
                                    EnsureUnblocked(path, ".gha");
                                else
                                    EnsureBlocked(path, ".gha");
                            }
                        }
                    }

                    // Selected → UserObjects & GHPY
                    UnblockMany(p.UserobjectPath, ".ghuser");
                    UnblockMany(p.ghpyPath, ".ghpy");

                    if ((p.UserobjectPath?.Count ?? 0) > 0 && (p.GhaPaths == null || p.GhaPaths.Count == 0))
                    {
                        RhinoApp.WriteLine($"[Gh Mode Manager] ⚠ '{p.Name}' has .ghuser but no .gha detected. Ensure the provider plugin is also selected.");
                    }
                }
                catch (Exception ex)
                {
                    RhinoApp.WriteLine($"[Gh Mode Manager] ❌ Error while processing '{p?.Name}': {ex.Message}");
                }
            }
        }

        // ---------- Selection expansion & helpers ----------

        private static void ExpandSelectionToFamilies(List<PluginItem> all)
        {
            if (all == null || all.Count == 0) return;

            // Build family buckets by normalized key (letters+digits only, lowercase)
            string Key(string s)
            {
                if (string.IsNullOrWhiteSpace(s)) return string.Empty;
                var filtered = new string(s.Where(char.IsLetterOrDigit).ToArray());
                return filtered.ToLowerInvariant();
            }

            var byKey = new Dictionary<string, List<PluginItem>>();
            foreach (var p in all)
            {
                var k = Key(p?.Name ?? "");
                if (!byKey.TryGetValue(k, out var list)) byKey[k] = list = new List<PluginItem>();
                list.Add(p);
            }

            // If any item in a family is selected, select all in that family
            foreach (var kv in byKey)
            {
                if (kv.Value.Any(pi => pi.IsSelected))
                    foreach (var pi in kv.Value) pi.IsSelected = true;
            }

            // Map AssemblyName -> items (helps when family names differ)
            var asmMap = new Dictionary<string, List<PluginItem>>(StringComparer.OrdinalIgnoreCase);
            foreach (var p in all)
            {
                if (p?.GhaPaths == null) continue;
                foreach (var gha in p.GhaPaths.Where(File.Exists))
                {
                    try
                    {
                        var an = AssemblyName.GetAssemblyName(gha).Name; // e.g., "Elefront"
                        if (!asmMap.TryGetValue(an, out var list)) asmMap[an] = list = new List<PluginItem>();
                        if (!list.Contains(p)) list.Add(p);
                    }
                    catch { /* bad file; ignore */ }
                }
            }

            // If a selected item has only userobjects, try to select provider GHA by matching assembly name to family key
            foreach (var p in all.Where(x => x != null && x.IsSelected))
            {
                bool hasGha = (p.GhaPaths?.Count ?? 0) > 0;
                bool hasUo = (p.UserobjectPath?.Count ?? 0) > 0;
                if (!hasUo || hasGha) continue;

                var k = new string((p.Name ?? "").Where(char.IsLetterOrDigit).ToArray()).ToLowerInvariant();
                foreach (var kv in asmMap)
                {
                    var ak = new string(kv.Key.Where(char.IsLetterOrDigit).ToArray()).ToLowerInvariant();
                    if (ak == k)
                        foreach (var prov in kv.Value) prov.IsSelected = true;
                }
            }
        }

        private static bool IsSystemComponentPath(string path)
        {
            if (string.IsNullOrWhiteSpace(path)) return false;
            return path.IndexOf(@"\Plug-ins\Grasshopper\Components", StringComparison.OrdinalIgnoreCase) >= 0
                && path.IndexOf(@"\Rhino ", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static bool IsAlwaysOn(string path)
        {
            try
            {
                var name = Path.GetFileName(path) ?? string.Empty;
                return AlwaysOnFileHints.Any(h => name.IndexOf(h, StringComparison.OrdinalIgnoreCase) >= 0);
            }
            catch { return false; }
        }

        private static void BlockMany(IEnumerable<string> paths, string expectedExt)
        {
            if (paths == null) return;
            foreach (var raw in paths.Where(s => !string.IsNullOrWhiteSpace(s)))
                EnsureBlocked(raw, expectedExt);
        }

        private static void UnblockMany(IEnumerable<string> paths, string expectedExt)
        {
            if (paths == null) return;
            foreach (var raw in paths.Where(s => !string.IsNullOrWhiteSpace(s)))
                EnsureUnblocked(raw, expectedExt);
        }

        private static bool EnsureBlocked(string originalPath, string expectedExt)
        {
            var (clean, disabled) = NormalizePaths(originalPath, expectedExt);

            // Never block always-on providers (e.g., GhPython)
            if (IsAlwaysOn(clean))
            {
                RhinoApp.WriteLine($"[Gh Mode Manager] • Always-on provider: {Path.GetFileName(clean)} (skipping block)");
                return true;
            }

            try
            {
                if (!File.Exists(clean) && File.Exists(disabled))
                {
                    RhinoApp.WriteLine($"[Gh Mode Manager] • Already blocked: {Path.GetFileName(originalPath)}");
                    return true;
                }

                if (File.Exists(clean))
                {
                    SafeMove(clean, disabled, $"block {Path.GetFileName(clean)}");
                    return true;
                }

                RhinoApp.WriteLine($"[Gh Mode Manager] • Skip (missing): {Path.GetFileName(originalPath)}");
                return false;
            }
            catch (Exception ex)
            {
                RhinoApp.WriteLine($"[Gh Mode Manager] ⚠️ Block failed ({Path.GetFileName(originalPath)}): {ex.Message}");
                return false;
            }
        }

        private static bool EnsureUnblocked(string originalPath, string expectedExt)
        {
            var (clean, disabled) = NormalizePaths(originalPath, expectedExt);
            try
            {
                if (File.Exists(clean))
                {
                    RhinoApp.WriteLine($"[Gh Mode Manager] • Already unblocked: {Path.GetFileName(originalPath)}");
                    return true;
                }

                if (File.Exists(disabled))
                {
                    SafeMove(disabled, clean, $"unblock {Path.GetFileName(clean)}");
                    return true;
                }

                RhinoApp.WriteLine($"[Gh Mode Manager] • Skip (missing): {Path.GetFileName(originalPath)}");
                return false;
            }
            catch (Exception ex)
            {
                RhinoApp.WriteLine($"[Gh Mode Manager] ⚠️ Unblock failed ({Path.GetFileName(originalPath)}): {ex.Message}");
                return false;
            }
        }

        private static (string clean, string disabled) NormalizePaths(string input, string expectedExt)
        {
            var p = input?.Trim() ?? string.Empty;

            if (p.EndsWith(DisabledSuffix, StringComparison.OrdinalIgnoreCase))
            {
                var clean = p.Substring(0, p.Length - DisabledSuffix.Length);
                return (clean, p);
            }
            return (p, p + DisabledSuffix);
        }

        private static void SafeMove(string src, string dst, string actionLabel)
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(dst) ?? Path.GetTempPath());

                if (File.Exists(dst))
                {
                    File.SetAttributes(dst, FileAttributes.Normal);
                    File.Delete(dst);
                }

                File.Move(src, dst);
                RhinoApp.WriteLine($"[Gh Mode Manager] • {actionLabel}");
            }
            catch (UnauthorizedAccessException uae)
            {
                RhinoApp.WriteLine($"[Gh Mode Manager] ⚠️ Move denied for {Path.GetFileName(src)} → {uae.Message}");
            }
            catch (IOException ioEx)
            {
                RhinoApp.WriteLine($"[Gh Mode Manager] ⚠️ Move failed {Path.GetFileName(src)} → {Path.GetFileName(dst)}: {ioEx.Message}");
            }
        }

        private static string[] GetKnownRoots()
        {
            var appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            var ghLib = Path.Combine(appData, "Grasshopper", "Libraries");
            var yak8 = Path.Combine(appData, "McNeel", "Rhinoceros", "packages", "8.0");
            var yak7 = Path.Combine(appData, "McNeel", "Rhinoceros", "packages", "7.0");
            return new[] { ghLib, yak8, yak7 };
        }

        private static IEnumerable<string> SafeEnumerateFiles(string root, string pattern)
        {
            try { return Directory.EnumerateFiles(root, pattern, SearchOption.AllDirectories); }
            catch { return Array.Empty<string>(); }
        }
    }
}
